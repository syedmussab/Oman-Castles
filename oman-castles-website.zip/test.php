<?php
echo "Hello PHP!";
?>